const express = require('express');
const axios = require('axios');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

const urlObjetivo = 'https://www.x-rates.com/calculator/?from=GBP&to=MXN&amount=1';

// --- RUTA 1: PARA EL NAVEGADOR (HTML) ---
app.get('/', (req, res) => {
    // (Aquí iría tu código anterior para mostrar el HTML, lo dejé abreviado 
    // para enfocarme en la parte del JSON, pero puedes mantener el que tenías)
    res.send('<h1>Ve a <a href="/api/libra">/api/libra</a> para ver el JSON en Postman</h1>');
});

// --- RUTA 2: PARA POSTMAN (JSON) ---
app.get('/api/libra', (req, res) => {
    console.log('Postman solicitando JSON...');

    axios.get(urlObjetivo)
        .then(response => {
            const htmlExterno = response.data;

            // --- MISMA LÓGICA DE BÚSQUEDA (SCRAPING) ---
            const referencia = 'class="ccOutputRslt">'; 
            const indiceInicio = htmlExterno.indexOf(referencia);

            let precioLibra = "0.00";

            if (indiceInicio !== -1) {
                const inicioValor = indiceInicio + referencia.length;
                const indiceFin = htmlExterno.indexOf('<', inicioValor);
                
                // Obtenemos el texto (Ej: "26.52 MXN")
                let textoCompleto = htmlExterno.substring(inicioValor, indiceFin);
                
                // Opcional: Limpiamos para dejar solo el número (quitamos " MXN")
                precioLibra = textoCompleto.replace(' MXN', '').trim();
            }

            // --- AQUÍ ESTÁ LA MAGIA PARA POSTMAN ---
            // En lugar de res.send(html), usamos res.json(objeto)
            res.json({
                nombre: "libra",
                valor: precioLibra,
                moneda: "MXN",
                fecha: new Date().toLocaleString()
            });

        })
        .catch(error => {
            console.error(error);
            // También devolvemos error en formato JSON
            res.status(500).json({ 
                error: "No se pudo obtener la cotización",
                detalle: error.message 
            });
        });
});

app.listen(port, () => {
    console.log(`Servidor listo.`);
    console.log(`Prueba el JSON en: http://localhost:${port}/api/libra`);
});